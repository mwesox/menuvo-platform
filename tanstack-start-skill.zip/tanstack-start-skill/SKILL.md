---
name: tanstack-start-skill
description: This skill provides guidance for TanStack Start development including server functions with createServerFn, server routes/API endpoints, middleware with createMiddleware, route loaders, error handling with redirect/notFound, and Sentry instrumentation. This skill should be used when building full-stack features, creating API endpoints, implementing server-side logic, or working with data loading patterns in TanStack Start applications.
---

# TanStack Start Development Skill

This skill provides patterns and best practices for developing with TanStack Start, a full-stack React framework built on TanStack Router and Vite.

## Server Functions

Server functions are type-safe RPC functions that run on the server but can be called from client code.

### Basic Server Function

```tsx
import { createServerFn } from '@tanstack/react-start'

export const getServerTime = createServerFn().handler(async () => {
  return new Date().toISOString()
})
```

### With Input Validation (Zod)

```tsx
import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'

const CreateUserSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  age: z.number().min(0),
})

export const createUser = createServerFn({ method: 'POST' })
  .inputValidator(CreateUserSchema)
  .handler(async ({ data }) => {
    // data is fully typed from Zod schema
    return { id: 1, ...data }
  })
```

### HTTP Methods

```tsx
// GET (default)
export const getData = createServerFn().handler(async () => {
  return { message: 'Hello' }
})

// POST
export const saveData = createServerFn({ method: 'POST' }).handler(async () => {
  return { success: true }
})
```

### FormData Handling

```tsx
export const submitForm = createServerFn({ method: 'POST' })
  .inputValidator((data) => {
    if (!(data instanceof FormData)) {
      throw new Error('Expected FormData')
    }
    return {
      name: data.get('name')?.toString() || '',
      email: data.get('email')?.toString() || '',
    }
  })
  .handler(async ({ data }) => {
    return { success: true, name: data.name }
  })
```

## Error Handling

### Redirects

```tsx
import { redirect } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'

export const requireAuth = createServerFn().handler(async () => {
  const user = await getCurrentUser()
  if (!user) {
    throw redirect({ to: '/login' })
  }
  return user
})
```

### Not Found

```tsx
import { notFound } from '@tanstack/react-router'
import { createServerFn } from '@tanstack/react-start'

export const getPost = createServerFn()
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    const post = await db.findPost(data.id)
    if (!post) {
      throw notFound()
    }
    return post
  })
```

## Server Routes (API Endpoints)

### File Naming Conventions

Routes are file-based in `src/routes/`:
- `/routes/api.hello.ts` -> `/api/hello`
- `/routes/api.users.ts` -> `/api/users`
- `/routes/api.users.$id.ts` -> `/api/users/:id`
- `/routes/api.users.$id.posts.ts` -> `/api/users/:id/posts`

### Basic API Route

```tsx
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/api/hello')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        return Response.json({ message: 'Hello!' })
      },
    },
  },
})
```

### Multiple HTTP Methods

```tsx
export const Route = createFileRoute('/api/users')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const users = await db.query.users.findMany()
        return Response.json(users)
      },
      POST: async ({ request }) => {
        const body = await request.json()
        const user = await db.insert(users).values(body).returning()
        return Response.json(user, { status: 201 })
      },
    },
  },
})
```

### Dynamic Parameters

```tsx
export const Route = createFileRoute('/api/users/$id')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const user = await db.query.users.findFirst({
          where: eq(users.id, params.id)
        })
        if (!user) {
          return new Response('Not found', { status: 404 })
        }
        return Response.json(user)
      },
    },
  },
})
```

## Middleware

### Creating Middleware

```tsx
import { createMiddleware } from '@tanstack/react-start'

const loggingMiddleware = createMiddleware().server(({ next, request }) => {
  console.log(`${request.method} ${request.url}`)
  return next()
})
```

### Authentication Middleware

```tsx
const authMiddleware = createMiddleware().server(async ({ next, context }) => {
  const user = await getCurrentUser()
  if (!user) {
    throw redirect({ to: '/login' })
  }
  return next({ context: { user } })
})
```

### Middleware Composition

```tsx
const adminMiddleware = createMiddleware()
  .middleware([authMiddleware])  // Depends on authMiddleware
  .server(async ({ next, context }) => {
    if (!context.user.isAdmin) {
      throw new Error('Unauthorized')
    }
    return next()
  })
```

### Applying to Server Functions

```tsx
const protectedFn = createServerFn()
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    // context.user is available and typed
    return { userId: context.user.id }
  })
```

### Input Validation in Middleware

```tsx
import { zodValidator } from '@tanstack/zod-adapter'

const validatedMiddleware = createMiddleware()
  .inputValidator(zodValidator(z.object({ workspaceId: z.string() })))
  .server(async ({ next, data }) => {
    const workspace = await getWorkspace(data.workspaceId)
    return next({ context: { workspace } })
  })
```

## Route Loaders

### Basic Loader

```tsx
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/posts')({
  loader: async () => {
    return await getPosts()
  },
  component: PostsPage,
})

function PostsPage() {
  const posts = Route.useLoaderData()
  return <ul>{posts.map(p => <li key={p.id}>{p.title}</li>)}</ul>
}
```

### Loader with Server Function

```tsx
const getPosts = createServerFn().handler(async () => {
  return await db.query.posts.findMany()
})

export const Route = createFileRoute('/posts')({
  loader: () => getPosts(),
  component: PostsPage,
})
```

### Loader with Parameters

```tsx
export const Route = createFileRoute('/posts/$id')({
  loader: async ({ params }) => {
    return await getPost({ data: { id: params.id } })
  },
})
```

### beforeLoad for Auth

```tsx
export const Route = createFileRoute('/dashboard')({
  beforeLoad: async () => {
    const user = await requireAuth()
    return { user }
  },
  loader: async ({ context }) => {
    return await getDashboardData({ data: { userId: context.user.id } })
  },
})
```

## Sentry Instrumentation

### Wrapping Server Functions

```tsx
import * as Sentry from '@sentry/tanstackstart-react'
import { createServerFn } from '@tanstack/react-start'

export const fetchData = createServerFn().handler(async () => {
  return Sentry.startSpan({ name: 'Fetching data from API' }, async () => {
    const response = await fetch('https://api.example.com/data')
    return response.json()
  })
})
```

### Database Operations

```tsx
export const getUsers = createServerFn().handler(async () => {
  return Sentry.startSpan({ name: 'Database: Get all users' }, async () => {
    return await db.query.users.findMany()
  })
})
```

## TanStack Query Integration

### With Route Loader

```tsx
import { queryOptions } from '@tanstack/react-query'

const postsQueryOptions = queryOptions({
  queryKey: ['posts'],
  queryFn: () => getPosts(),
})

export const Route = createFileRoute('/posts')({
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(postsQueryOptions)
  },
  component: PostsPage,
})

function PostsPage() {
  const { data } = useSuspenseQuery(postsQueryOptions)
  return <PostList posts={data} />
}
```

### Mutations

```tsx
function CreatePostForm() {
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: (data: CreatePostInput) => createPost({ data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] })
    },
  })

  return (
    <form onSubmit={(e) => {
      e.preventDefault()
      mutation.mutate(formData)
    }}>
      {/* form fields */}
    </form>
  )
}
```

## Best Practices

1. **Always validate inputs** - Use Zod schemas with `inputValidator` for type safety
2. **Use server functions for data mutations** - Prefer `createServerFn` over raw API routes
3. **Instrument with Sentry** - Wrap expensive operations with `Sentry.startSpan`
4. **Compose middleware** - Build reusable middleware for auth, logging, validation
5. **Leverage route context** - Pass data between `beforeLoad`, `loader`, and components
6. **Use TanStack Query for caching** - Integrate with route loaders for optimal data fetching
